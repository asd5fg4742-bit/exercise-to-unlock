package ir.vyron.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import ir.vyron.app.data.Profile
import ir.vyron.app.data.ProfileStore
import kotlinx.coroutines.launch

private val Accent = Color(0xFF39FF7A)
private val Background = Color(0xFF0B0F0D)
private val SurfaceColor = Color(0xFF131A16)
private val TextColor = Color(0xFFEAF5EE)
private val MutedColor = Color(0xFF8FA398)

private val VyronColors = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF04140A),
    background = Background,
    onBackground = TextColor,
    surface = SurfaceColor,
    onSurface = TextColor,
    surfaceVariant = Color(0xFF1B241F),
    onSurfaceVariant = MutedColor
)

/** انتخاب متن بر اساس زبان. */
private fun tr(lang: String, fa: String, en: String): String =
    if (lang == "en") en else fa

@Composable
fun VyronApp() {
    val context = LocalContext.current
    val store = remember(context) { ProfileStore(context.applicationContext) }
    val profile by store.profile.collectAsState(initial = null)
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = VyronColors) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Background
        ) {
            val p: Profile? = profile
            val lang = p?.language ?: ""
            val direction = if (lang == "en") LayoutDirection.Ltr else LayoutDirection.Rtl

            CompositionLocalProvider(LocalLayoutDirection provides direction) {
                when {
                    p == null -> Box(Modifier.fillMaxSize())

                    lang.isEmpty() -> LanguageScreen(
                        onPick = { code -> scope.launch { store.saveLanguage(code) } }
                    )

                    p.name.isBlank() || editing -> ProfileScreen(
                        lang = lang,
                        initial = p,
                        onSave = { name, goal ->
                            scope.launch { store.saveProfile(name, goal) }
                            editing = false
                        },
                        onCancel = if (editing) ({ editing = false }) else null
                    )

                    else -> DashboardScreen(
                        lang = lang,
                        profile = p,
                        onEdit = { editing = true },
                        onToggleLanguage = {
                            scope.launch {
                                store.saveLanguage(if (lang == "fa") "en" else "fa")
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun LanguageScreen(onPick: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "VYRON",
            style = MaterialTheme.typography.displaySmall,
            color = Accent
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "ورزش کن، آزاد شو",
            style = MaterialTheme.typography.bodyLarge,
            color = MutedColor
        )
        Spacer(Modifier.height(40.dp))
        Text(
            text = "زبان را انتخاب کن / Choose your language",
            style = MaterialTheme.typography.titleMedium,
            color = TextColor
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { onPick("fa") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("فارسی")
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = { onPick("en") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("English")
        }
    }
}

@Composable
private fun ProfileScreen(
    lang: String,
    initial: Profile,
    onSave: (String, String) -> Unit,
    onCancel: (() -> Unit)?
) {
    var name by remember { mutableStateOf(initial.name) }
    var goal by remember { mutableStateOf(initial.goal) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        Text(
            text = tr(lang, "پروفایل خود را بساز", "Create your profile"),
            style = MaterialTheme.typography.headlineSmall,
            color = Accent
        )
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text(tr(lang, "نام", "Name")) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = goal,
            onValueChange = { goal = it },
            label = { Text(tr(lang, "هدف ورزشی (اختیاری)", "Fitness goal (optional)")) },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { onSave(name.trim(), goal.trim()) },
            enabled = name.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(tr(lang, "ذخیره", "Save"))
        }
        if (onCancel != null) {
            TextButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) {
                Text(tr(lang, "انصراف", "Cancel"))
            }
        }
    }
}

@Composable
private fun DashboardScreen(
    lang: String,
    profile: Profile,
    onEdit: () -> Unit,
    onToggleLanguage: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text(
            text = tr(lang, "سلام، ${profile.name}", "Hi, ${profile.name}"),
            style = MaterialTheme.typography.headlineSmall,
            color = Accent
        )
        Spacer(Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceColor)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    text = tr(lang, "هدف ورزشی", "Fitness goal"),
                    style = MaterialTheme.typography.titleMedium,
                    color = TextColor
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = if (profile.goal.isBlank()) {
                        tr(lang, "هنوز هدفی ثبت نشده", "No goal set yet")
                    } else {
                        profile.goal
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedColor
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceColor)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    text = tr(lang, "تمرین امروز", "Today's workout"),
                    style = MaterialTheme.typography.titleMedium,
                    color = TextColor
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = tr(
                        lang,
                        "این بخش در مراحل بعدی ساخته می‌شود.",
                        "This section will be built in later stages."
                    ),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedColor
                )
            }
        }

        Spacer(Modifier.height(24.dp))

        OutlinedButton(onClick = onEdit, modifier = Modifier.fillMaxWidth()) {
            Text(tr(lang, "ویرایش پروفایل", "Edit profile"))
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onToggleLanguage, modifier = Modifier.fillMaxWidth()) {
            Text(tr(lang, "Switch to English", "تغییر به فارسی"))
        }
    }
}
