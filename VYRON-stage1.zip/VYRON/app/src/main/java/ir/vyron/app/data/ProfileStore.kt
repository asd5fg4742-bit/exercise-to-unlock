package ir.vyron.app.data

import android.content.Context
import androidx.datastore.core.IOException
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "vyron_settings")

/**
 * language: null یعنی اولین اجرا و کاربر هنوز زبان انتخاب نکرده.
 */
data class Profile(
    val language: String? = null,
    val name: String = "",
    val goal: String = ""
)

class ProfileStore(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("language")
        val NAME = stringPreferencesKey("name")
        val GOAL = stringPreferencesKey("goal")
    }

    val profile: Flow<Profile> = context.settingsDataStore.data
        .catch { error ->
            // خطای خواندن فایل نباید برنامه را خراب کند
            if (error is IOException) emit(emptyPreferences()) else throw error
        }
        .map { prefs: Preferences ->
            Profile(
                language = prefs[Keys.LANGUAGE],
                name = prefs[Keys.NAME] ?: "",
                goal = prefs[Keys.GOAL] ?: ""
            )
        }

    suspend fun saveLanguage(code: String) {
        context.settingsDataStore.edit { it[Keys.LANGUAGE] = code }
    }

    suspend fun saveProfile(name: String, goal: String) {
        context.settingsDataStore.edit {
            it[Keys.NAME] = name
            it[Keys.GOAL] = goal
        }
    }
}
