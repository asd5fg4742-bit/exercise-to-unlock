package com.vyron.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.Toast
import org.json.JSONArray

/** User-enabled focus aid. Android does not permit an ordinary app to create a tamper-proof full-device lock. */
class VyronBlockerService : AccessibilityService() {
    private val essentialPackages = setOf(
        "com.android.systemui", "com.android.settings", "com.android.phone",
        "com.android.server.telecom", "com.android.emergency", "com.android.dialer",
        "com.google.android.dialer", "com.samsung.android.dialer", "com.samsung.android.incallui",
        "com.android.contacts", "com.google.android.contacts", "com.samsung.android.app.contacts",
        "com.android.mms", "com.google.android.apps.messaging", "com.samsung.android.messaging"
    )

    /** Apps kept available in student mode: Google search, calculators, and common AI study tools. */
    private val studyAllowedPackages = setOf(
        // Google Search / Google app
        "com.google.android.googlequicksearchbox",
        // Calculators: Google, AOSP, Samsung, Xiaomi, OnePlus
        "com.google.android.calculator", "com.android.calculator2",
        "com.sec.android.app.popupcalculator", "com.miui.calculator",
        "com.oneplus.calculator", "com.coloros.calculator",
        // AI study assistants
        "com.openai.chatgpt", "com.google.android.apps.bard",
        "com.anthropic.claude", "com.microsoft.copilot",
        "com.perplexity.ai", "com.deepseek.chat", "com.x.ai",
        "ai.perplexity.app.android", "com.poe.android"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg in essentialPackages || pkg == "com.android.systemui") return

        val prefs = getSharedPreferences("vyron_store", MODE_PRIVATE)
        // Learning tools remain available even when student default-lock mode is enabled.
        // This allowlist intentionally takes priority over manually blocked packages.
        if (pkg in studyAllowedPackages) return
        val parentPauseUntil = prefs.getLong("parent_pause_until", 0L)
        if (System.currentTimeMillis() < parentPauseUntil) return
        val smartLock = prefs.getBoolean("smart_lock_enabled", false)
        val studentDefaultLock = prefs.getBoolean("student_default_lock", false)
        val unlockUntil = prefs.getLong("smart_unlock_until", 0L)
        val lockWindowExpired = System.currentTimeMillis() >= unlockUntil
        val smartLockActive = (smartLock || studentDefaultLock) && lockWindowExpired

        val manuallyBlocked = try {
            val a = JSONArray(prefs.getString("blocked_packages", "[]") ?: "[]")
            (0 until a.length()).map { a.optString(it) }.toSet()
        } catch (_: Exception) { emptySet() }

        val isHomeLauncher = try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName == pkg
        } catch (_: Exception) { false }
        if (isHomeLauncher) return

        if (smartLockActive || pkg in manuallyBlocked) {
            Toast.makeText(this, if (smartLockActive) "برای بازشدن برنامه‌ها، ۳۰ اسکوات را با VYRON تکمیل کن" else "این برنامه در حالت تمرکز محدود شده است", Toast.LENGTH_SHORT).show()
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    override fun onInterrupt() {}
}
