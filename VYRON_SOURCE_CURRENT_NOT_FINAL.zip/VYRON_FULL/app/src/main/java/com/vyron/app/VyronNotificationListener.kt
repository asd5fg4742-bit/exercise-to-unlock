package com.vyron.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

/** Stores only notification content supplied by Android after the user explicitly enables notification access. */
class VyronNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val body = extras.getCharSequence("android.text")?.toString().orEmpty()
        if (title.isBlank() && body.isBlank()) return
        val prefs = getSharedPreferences("vyron_store", MODE_PRIVATE)
        val old = try { JSONArray(prefs.getString("recent_notifications", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val next = JSONArray()
        next.put(JSONObject().put("app", sbn.packageName).put("title", title.take(200)).put("text", body.take(500)).put("time", sbn.postTime))
        for (i in 0 until minOf(old.length(), 48)) next.put(old.optJSONObject(i))
        prefs.edit().putString("recent_notifications", next.toString()).apply()
    }
}
