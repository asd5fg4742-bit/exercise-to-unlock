package com.vyron.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Creates a 1080x1920 shareable workout card. The body graphic is decorative, not a medical/anatomical assessment. */
object StoryExporter {
    fun save(context: Context, workout: WorkoutItem?): Boolean {
        if (workout == null) {
            Toast.makeText(context, "اول یک تمرین ثبت کن", Toast.LENGTH_SHORT).show()
            return false
        }
        return try {
            val bitmap = Bitmap.createBitmap(1080, 1920, Bitmap.Config.ARGB_8888)
            val c = Canvas(bitmap)
            val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(8, 11, 10) }
            c.drawPaint(bg)
            val neon = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(182, 255, 57) }
            val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(242, 245, 242) }
            val muted = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(155, 166, 158) }
            val panel = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(20, 26, 23) }
            val bold = Typeface.create("sans-serif", Typeface.BOLD)
            fun text(s: String, x: Float, y: Float, size: Float, paint: Paint, face: Typeface? = null) {
                paint.textSize = size
                paint.typeface = face ?: Typeface.create("sans-serif", Typeface.NORMAL)
                c.drawText(s.take(70), x, y, paint)
            }
            c.drawRoundRect(RectF(52f, 56f, 1028f, 1864f), 44f, 44f, panel)
            text("VYRON", 92f, 150f, 58f, neon, bold)
            text("WORKOUT LOG", 92f, 205f, 26f, muted)
            c.drawRoundRect(RectF(92f, 270f, 988f, 540f), 28f, 28f, bg)
            text(workout.title, 128f, 360f, 52f, white, bold)
            text("${workout.duration} minutes", 128f, 425f, 34f, neon, bold)
            text(workout.date, 128f, 480f, 26f, muted)
            // Decorative simplified body silhouette and highlighted muscle zones.
            val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(70, 82, 73) }
            c.drawCircle(540f, 660f, 64f, body)
            c.drawRoundRect(RectF(450f, 720f, 630f, 1035f), 72f, 72f, body)
            c.drawRoundRect(RectF(350f, 735f, 445f, 1000f), 42f, 42f, body)
            c.drawRoundRect(RectF(635f, 735f, 730f, 1000f), 42f, 42f, body)
            c.drawRoundRect(RectF(465f, 1010f, 530f, 1320f), 28f, 28f, body)
            c.drawRoundRect(RectF(550f, 1010f, 615f, 1320f), 28f, 28f, body)
            val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(182, 255, 57); alpha = 210 }
            val lower = workout.title.lowercase(Locale.ROOT)
            if (listOf("پا", "leg", "squat", "فوتبال", "football", "دویدن", "running").any { lower.contains(it) }) {
                c.drawRoundRect(RectF(465f, 1010f, 530f, 1320f), 28f, 28f, accent)
                c.drawRoundRect(RectF(550f, 1010f, 615f, 1320f), 28f, 28f, accent)
            } else {
                c.drawRoundRect(RectF(450f, 740f, 630f, 890f), 56f, 56f, accent)
                c.drawRoundRect(RectF(350f, 735f, 445f, 880f), 42f, 42f, accent)
                c.drawRoundRect(RectF(635f, 735f, 730f, 880f), 42f, 42f, accent)
            }
            text("SESSION SUMMARY", 92f, 1410f, 28f, neon, bold)
            text("Duration: ${workout.duration} min", 92f, 1480f, 34f, white)
            text("Date: ${workout.date}", 92f, 1535f, 28f, muted)
            val note = workout.notes.ifBlank { "No extra details recorded" }
            text("Details: $note", 92f, 1605f, 25f, white)
            text("Muscle illustration is decorative, not a measured result.", 92f, 1740f, 20f, muted)
            text("DISCIPLINE OVER EXCUSES", 92f, 1810f, 25f, neon, bold)

            val name = "VYRON_story_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.png"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VYRON")
            }
            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create image entry")
            context.contentResolver.openOutputStream(uri).use { out ->
                if (out == null || !bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) throw IllegalStateException("Could not save image")
            }
            bitmap.recycle()
            Toast.makeText(context, "استوری در پوشهٔ Pictures/VYRON ذخیره شد", Toast.LENGTH_LONG).show()
            true
        } catch (e: Exception) {
            Toast.makeText(context, "ذخیره استوری ناموفق بود: ${e.message ?: "خطای ناشناخته"}", Toast.LENGTH_LONG).show()
            false
        }
    }
}
