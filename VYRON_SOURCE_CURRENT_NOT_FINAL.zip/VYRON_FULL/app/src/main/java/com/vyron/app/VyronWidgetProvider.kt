package com.vyron.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class VyronWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val date = SimpleDateFormat("EEEE، d MMMM", Locale("fa", "IR")).format(Date())
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.vyron_widget)
            views.setTextViewText(R.id.widget_date, "امروز: $date")
            manager.updateAppWidget(id, views)
        }
    }
}
