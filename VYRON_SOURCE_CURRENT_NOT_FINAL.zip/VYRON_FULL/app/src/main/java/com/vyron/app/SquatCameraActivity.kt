package com.vyron.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import java.util.concurrent.Executors
import kotlin.math.acos
import kotlin.math.sqrt

private const val TARGET_SQUATS = 30
private const val UNLOCK_MS = 30L * 60L * 1000L

class SquatCameraActivity : ComponentActivity() {
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private var reps by mutableIntStateOf(0)
    private var message by mutableStateOf("تمام بدن را در کادر دوربین قرار بده")
    private var cameraReady by mutableStateOf(false)
    private var completed by mutableStateOf(false)
    private var wasDown = false
    private var lastCountAt = 0L
    private var previewView: PreviewView? = null
    private var cameraStarted = false
    private val poseDetector by lazy {
        PoseDetection.getClient(PoseDetectorOptions.Builder().setDetectorMode(PoseDetectorOptions.STREAM_MODE).build())
    }
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else message = "برای شمارش اسکوات، مجوز دوربین لازم است."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFB6FF39), background = Color(0xFF080B0A), surface = Color(0xFF141A17))) {
                Column(Modifier.fillMaxSize().background(Color(0xFF080B0A)).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { finish() }) { Icon(Icons.Default.ArrowBack, null, tint = Color(0xFFB6FF39)) }
                        Text("قفل هوشمند VYRON", color = Color(0xFFB6FF39), fontSize = 22.sp)
                    }
                    Text("اسکوات: $reps از $TARGET_SQUATS", color = Color.White, fontSize = 28.sp)
                    Text(message, color = Color(0xFFB6FF39), fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    AndroidView(factory = { ctx -> PreviewView(ctx).also { view ->
                        previewView = view; view.scaleType = PreviewView.ScaleType.FILL_CENTER
                        view.post { if (ContextCompat.checkSelfPermission(this@SquatCameraActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera() }
                    } }, modifier = Modifier.fillMaxWidth().weight(1f))
                    Spacer(Modifier.height(12.dp))
                    if (completed) {
                        Text("تمرین تأیید شد. ۳۰ دقیقه دسترسی فعال شد.", color = Color(0xFFB6FF39))
                        Button(onClick = { finish() }) { Text("ادامه") }
                    } else {
                        Text("از پهلو یا سه‌رخ بایست؛ پایین رفتن و برگشت کامل یک تکرار حساب می‌شود.", color = Color.LightGray, fontSize = 12.sp)
                    }
                }
            }
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) permission.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        if (cameraStarted || previewView == null || ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        cameraStarted = true
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val view = previewView ?: run { cameraStarted = false; return@addListener }
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(view.surfaceProvider) }
                val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                analysis.setAnalyzer(cameraExecutor) { proxy ->
                    val media = proxy.image
                    if (media == null || completed) { proxy.close(); return@setAnalyzer }
                    val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                    poseDetector.process(image)
                        .addOnSuccessListener { pose -> processPose(pose) }
                        .addOnFailureListener { message = "تشخیص بدن انجام نشد؛ نور و فاصله را بررسی کن." }
                        .addOnCompleteListener { proxy.close() }
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis)
                cameraReady = true
            } catch (_: Exception) { cameraStarted = false; message = "دوربین در دسترس نیست. برنامه دیگری را که از دوربین استفاده می‌کند ببند." }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun processPose(pose: Pose) {
        if (completed) return
        val left = kneeAngle(pose, true)
        val right = kneeAngle(pose, false)
        val angle = listOfNotNull(left, right).minOrNull()
        if (angle == null) { message = "لگن، زانو و مچ پا باید دیده شوند"; return }
        if (angle < 105f) {
            wasDown = true
            message = "پایین رفتن تشخیص داده شد؛ حالا کامل بلند شو"
        } else if (angle > 155f && wasDown) {
            val now = SystemClock.elapsedRealtime()
            if (now - lastCountAt > 650) {
                reps = (reps + 1).coerceAtMost(TARGET_SQUATS)
                lastCountAt = now
                wasDown = false
                message = "تکرار ثبت شد"
                if (reps >= TARGET_SQUATS) finishWorkout()
            }
        } else if (angle > 125f) message = "آماده شو؛ با کنترل پایین برو"
    }

    private fun kneeAngle(pose: Pose, left: Boolean): Float? {
        val hip = pose.getPoseLandmark(if (left) com.google.mlkit.vision.pose.PoseLandmark.LEFT_HIP else com.google.mlkit.vision.pose.PoseLandmark.RIGHT_HIP) ?: return null
        val knee = pose.getPoseLandmark(if (left) com.google.mlkit.vision.pose.PoseLandmark.LEFT_KNEE else com.google.mlkit.vision.pose.PoseLandmark.RIGHT_KNEE) ?: return null
        val ankle = pose.getPoseLandmark(if (left) com.google.mlkit.vision.pose.PoseLandmark.LEFT_ANKLE else com.google.mlkit.vision.pose.PoseLandmark.RIGHT_ANKLE) ?: return null
        if (minOf(hip.inFrameLikelihood, knee.inFrameLikelihood, ankle.inFrameLikelihood) < 0.55f) return null
        val ax = hip.position.x - knee.position.x; val ay = hip.position.y - knee.position.y
        val bx = ankle.position.x - knee.position.x; val by = ankle.position.y - knee.position.y
        val dot = ax * bx + ay * by
        val denom = sqrt(ax * ax + ay * ay) * sqrt(bx * bx + by * by)
        if (denom < 1f) return null
        return Math.toDegrees(acos((dot / denom).coerceIn(-1f, 1f)).toDouble()).toFloat()
    }

    private fun finishWorkout() {
        completed = true
        message = "۳۰ اسکوات تکمیل شد"
        val prefs = getSharedPreferences("vyron_store", MODE_PRIVATE)
        prefs.edit().putBoolean("smart_lock_enabled", true)
            .putLong("smart_unlock_until", System.currentTimeMillis() + UNLOCK_MS).apply()
        message = "۳۰ اسکوات ثبت شد؛ ۳۰ دقیقه فرصت استفاده داری"
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        poseDetector.close()
    }
}
