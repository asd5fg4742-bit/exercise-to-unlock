package com.vyron.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.security.MessageDigest

private val Bg = Color(0xFF0B1020)
private val Panel = Color(0xFF151D31)
private val Neon = Color(0xFF6C8CFF)
private val Accent = Color(0xFFFF8066)
private val MainText = Color(0xFFF5F7FF)
private val Muted = Color(0xFFA7B1C8)

class MainActivity : ComponentActivity(), SensorEventListener {
    private var stepSensor: Sensor? = null
    private var stepsToday by mutableIntStateOf(0)
    private var baseSteps = -1f
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        stepSensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                VyronApp(stepSensorAvailable = stepSensor != null, steps = stepsToday,
                    requestSteps = { requestActivityPermission() },
                    openNotificationSettings = {
                        startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
                    })
            }
        }
    }
    private fun requestActivityPermission() {
        if (Build.VERSION.SDK_INT >= 29 &&
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), 91)
        } else {
            stepSensor?.let { (getSystemService(Context.SENSOR_SERVICE) as SensorManager).registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        }
    }
    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT < 29 || checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED) {
            stepSensor?.let { (getSystemService(Context.SENSOR_SERVICE) as SensorManager).registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        }
    }
    override fun onPause() {
        super.onPause()
        (getSystemService(Context.SENSOR_SERVICE) as SensorManager).unregisterListener(this)
    }
    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_STEP_COUNTER) {
            if (baseSteps < 0) baseSteps = event.values[0]
            stepsToday = (event.values[0] - baseSteps).toInt().coerceAtLeast(0)
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

data class TaskItem(val title: String, val kind: String, val done: Boolean = false)
data class WorkoutItem(val title: String, val duration: Int, val notes: String, val date: String)
data class Profile(val age: String = "", val height: String = "", val weight: String = "", val goal: String = "")

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("vyron_store", Context.MODE_PRIVATE)
    fun getString(key: String, default: String = "") = prefs.getString(key, default) ?: default
    fun putString(key: String, value: String) { prefs.edit().putString(key, value).apply() }
    fun tasks(): List<TaskItem> = try {
        val a = JSONArray(getString("tasks", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            TaskItem(o.optString("title"), o.optString("kind"), o.optBoolean("done"))
        }
    } catch (_: Exception) { emptyList() }
    fun saveTasks(list: List<TaskItem>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("title", it.title).put("kind", it.kind).put("done", it.done)) }
        putString("tasks", a.toString())
    }
    fun workouts(): List<WorkoutItem> = try {
        val a = JSONArray(getString("workouts", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            WorkoutItem(o.optString("title"), o.optInt("duration"), o.optString("notes"), o.optString("date"))
        }
    } catch (_: Exception) { emptyList() }
    fun saveWorkouts(list: List<WorkoutItem>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("title", it.title).put("duration", it.duration).put("notes", it.notes).put("date", it.date)) }
        putString("workouts", a.toString())
    }
    fun profile() = Profile(getString("age"), getString("height"), getString("weight"), getString("goal"))
    fun saveProfile(p: Profile) {
        putString("age", p.age); putString("height", p.height); putString("weight", p.weight); putString("goal", p.goal)
    }
}

@Composable
fun VyronApp(stepSensorAvailable: Boolean, steps: Int, requestSteps: () -> Unit, openNotificationSettings: () -> Unit) {
    val context = LocalContext.current
    val store = remember { LocalStore(context) }
    var selected by remember { mutableStateOf("خانه") }
    var tasks by remember { mutableStateOf(store.tasks()) }
    var workouts by remember { mutableStateOf(store.workouts()) }
    var profile by remember { mutableStateOf(store.profile()) }
    var focusMinutes by remember { mutableIntStateOf(25) }
    var focusRunning by remember { mutableStateOf(false) }
    var showTaskDialog by remember { mutableStateOf(false) }
    var showWorkoutDialog by remember { mutableStateOf(false) }
    var showStory by remember { mutableStateOf(false) }
    var showBlockDialog by remember { mutableStateOf(false) }
    var showParentDialog by remember { mutableStateOf(false) }
    var phoneOwner by remember { mutableStateOf(store.getString("phone_owner")) }
    // On a fresh install, configure a manager PIN before choosing an owner role.
    var ownerGateOpensSelection by remember { mutableStateOf(phoneOwner.isBlank()) }
    var showOwnerDialog by remember { mutableStateOf(false) }
    var showOwnerGateDialog by remember { mutableStateOf(phoneOwner.isBlank() || store.getString("parent_pin_hash").isBlank()) }
    var editMode by remember { mutableStateOf(false) }
    var showAccessPrompt by remember { mutableStateOf(false) }
    val blockerEnabledAtEntry = remember {
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            .orEmpty().contains("VyronBlockerService", ignoreCase = true)
    }
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("vyron_store", Context.MODE_PRIVATE)
        if (prefs.getBoolean("student_default_lock", false) && !blockerEnabledAtEntry) {
            showAccessPrompt = true
        }
    }
    val tabs = listOf("خانه", "برنامه", "تمرین", "کتابخانه", "چالش", "تمرکز", "پروفایل")
    val icons = listOf(Icons.Default.Home, Icons.Default.CalendarMonth, Icons.Default.FitnessCenter, Icons.Default.MenuBook, Icons.Default.TrackChanges, Icons.Default.Timer, Icons.Default.Person)

    MaterialTheme(colorScheme = darkColorScheme(primary = Neon, secondary = Accent, background = Bg, surface = Panel,
        onPrimary = Color.White, onBackground = MainText, onSurface = MainText)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                tabs.forEachIndexed { i, tab ->
                    NavigationBarItem(selected = selected == tab, onClick = { selected = tab },
                        icon = { Icon(icons[i], contentDescription = tab) }, label = { Text(tab, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Neon, selectedTextColor = Neon,
                            indicatorColor = Color(0xFF29385F), unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp, vertical = 12.dp)) {
                if (selected == "خانه") {
                    Surface(color = Panel, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Surface(color = Color(0xFF29385F), shape = RoundedCornerShape(18.dp), modifier = Modifier.size(54.dp)) {
                                Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(32.dp)) }
                            }
                            Column(Modifier.weight(1f)) {
                                Text(profile.goal.ifBlank { "ورزشکار وی‌رون" }, color = MainText, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text("سطح ۱  •  شروع مسیر پیشرفت", color = Muted, fontSize = 12.sp)
                            }
                            IconButton(onClick = { selected = "پروفایل" }) { Icon(Icons.Default.Settings, "پروفایل و تنظیمات", tint = Neon) }
                        }
                    }
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(selected, color = MainText, fontSize = 23.sp, fontWeight = FontWeight.Black)
                            Text(when(selected) {
                                "برنامه" -> "درس‌ها و کارهای روزانه"
                                "تمرین" -> "تمرین کن، ثبت کن، پیشرفت کن"
                                "تمرکز" -> "حواس‌پرتی کمتر، کار بیشتر"
                                "کتابخانه" -> "کتابخانهٔ حرکات ورزشی"
                                "چالش" -> "هدف شخصی، پیشرفت قابل‌اندازه‌گیری"
                                else -> "تنظیمات شخصی"
                            }, color = Muted, fontSize = 12.sp)
                        }
                        IconButton(onClick = { selected = "پروفایل" }) { Icon(Icons.Default.Settings, "تنظیمات", tint = Neon) }
                    }
                }
                if (editMode) {
                    CardBox {
                        Text("حالت ویرایش فعال است", color = Neon, fontWeight = FontWeight.Bold)
                        Text("در این نسخه، این دکمه نمایشی است و جابه‌جایی آزاد کارت‌ها هنوز پیاده‌سازی نشده.", color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                when(selected) {
                    "خانه" -> HomeScreen(tasks, workouts, steps, stepSensorAvailable, onTasks = { selected = "برنامه" }, onWorkout = { selected = "تمرین" }, onFocus = { selected = "تمرکز" }, onCompetition = { selected = "چالش" }, onLibrary = { selected = "کتابخانه" })
                    "برنامه" -> TasksScreen(tasks, onAdd = { showTaskDialog = true }, onToggle = { idx ->
                        tasks = tasks.toMutableList().also { it[idx] = it[idx].copy(done = !it[idx].done) }
                        store.saveTasks(tasks)
                    }, onDelete = { idx -> tasks = tasks.toMutableList().also { it.removeAt(idx) }; store.saveTasks(tasks) })
                    "تمرین" -> WorkoutScreen(workouts, onAdd = { showWorkoutDialog = true }, onStory = { showStory = true }, onSmartLock = { startActivity(Intent(this, SquatCameraActivity::class.java)) })
                    "کتابخانه" -> ExerciseLibraryScreen()
                    "چالش" -> CompetitionScreen()
                    "تمرکز" -> FocusScreen(focusMinutes, focusRunning, onMinutes = { focusMinutes = it }, onToggle = { focusRunning = !focusRunning })
                    "پروفایل" -> ProfileScreen(profile, phoneOwner, onSave = { profile = it; store.saveProfile(it) },
                        onChangePhoneOwner = {
                            ownerGateOpensSelection = true
                            showOwnerGateDialog = true
                        },
                        onNotifySettings = openNotificationSettings,
                        onBlockSettings = { showBlockDialog = true },
                        onParentSettings = { showParentDialog = true },
                        onStep = requestSteps, sensorAvailable = stepSensorAvailable)
                }
            }
        }
        if (showAccessPrompt) AlertDialog(
            onDismissRequest = { showAccessPrompt = false },
            title = { Text("راه‌اندازی قفل دانش‌آموزی", color = MainText, fontWeight = FontWeight.Bold) },
            text = { Text("برای اینکه وی‌رون بتواند برنامه‌های انتخاب‌شده را هنگام بازشدن محدود کند، اندروید باید دسترسی دسترس‌پذیری را از تنظیمات خودش تأیید کند. این مجوز را نمی‌شود مخفیانه روشن کرد.", color = Muted) },
            confirmButton = { TextButton(onClick = {
                showAccessPrompt = false
                context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) { Text("رفتن به تنظیمات", color = Neon) } },
            dismissButton = { TextButton(onClick = { showAccessPrompt = false }) { Text("بعداً", color = Muted) } }
        )
        if (showTaskDialog) TaskDialog(onDismiss = { showTaskDialog = false }, onSave = { title, kind ->
            tasks = tasks + TaskItem(title, kind); store.saveTasks(tasks); showTaskDialog = false
        })
        if (showWorkoutDialog) WorkoutDialog(onDismiss = { showWorkoutDialog = false }, onSave = { title, duration, notes ->
            val date = SimpleDateFormat("yyyy/MM/dd", Locale("fa", "IR")).format(Date())
            workouts = workouts + WorkoutItem(title, duration, notes, date); store.saveWorkouts(workouts); showWorkoutDialog = false
        })
        if (showStory) StoryDialog(workouts.lastOrNull(), onDismiss = { showStory = false }, onExport = { StoryExporter.save(context, workouts.lastOrNull()) })
        if (showBlockDialog) BlockAppsDialog(onDismiss = { showBlockDialog = false })
        if (showParentDialog) ParentControlsDialog(onDismiss = { showParentDialog = false })
        if (showOwnerGateDialog) ManagerAuthDialog(
            canDismiss = phoneOwner.isNotBlank(),
            onDismiss = { if (phoneOwner.isNotBlank()) showOwnerGateDialog = false },
            onAuthorized = {
                showOwnerGateDialog = false
                if (ownerGateOpensSelection) showOwnerDialog = true
            }
        )
        if (showOwnerDialog) PhoneOwnerDialog(
            currentOwner = phoneOwner,
            canDismiss = phoneOwner.isNotBlank(),
            onDismiss = { if (phoneOwner.isNotBlank()) showOwnerDialog = false },
            onChoose = { owner ->
                phoneOwner = owner
                store.putString("phone_owner", owner)
                showOwnerDialog = false
            }
        )
    }
}

data class ExerciseEntry(val id: Int, val name: String, val category: String, val level: String, val equipment: String, val target: String, val instructions: String, val dose: String, val rest: String, val safety: String)

@Composable fun StatPill(label: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Surface(color = Color(0xFF202820), shape = RoundedCornerShape(14.dp), modifier = modifier) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = Neon, modifier = Modifier.size(22.dp))
            Column { Text(value, color = MainText, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(label, color = Muted, fontSize = 11.sp) }
        }
    }
}

@Composable fun ProfileMetric(label: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = modifier) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Neon, modifier = Modifier.size(22.dp))
            Text(value, color = MainText, fontWeight = FontWeight.Bold)
            Text(label, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable fun ExerciseLibraryScreen() {
    val context = LocalContext.current
    val exercises = remember {
        try {
            val raw = context.assets.open("exercise_bank.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ExerciseEntry(o.optInt("id"), o.optString("name"), o.optString("category"), o.optString("level"), o.optString("equipment"), o.optString("target"), o.optString("instructions"), o.optString("dose"), o.optString("rest"), o.optString("safety"))
            }
        } catch (_: Exception) { emptyList() }
    }
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("همه") }
    var expandedId by remember { mutableIntStateOf(-1) }
    val categories = remember(exercises) { listOf("همه") + exercises.map { it.category }.distinct() }
    val filtered = remember(exercises, query, category) { exercises.filter { (category == "همه" || it.category == category) && (query.isBlank() || it.name.contains(query, true) || it.category.contains(query, true)) } }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        CardBox {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("کتابخانهٔ تمرین", color = MainText, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Text("${exercises.size} حرکت • ${categories.size - 1} رشته", color = Neon, fontSize = 13.sp)
                }
                Icon(Icons.Default.MenuBook, null, tint = Neon, modifier = Modifier.size(34.dp))
            }
            OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("جست‌وجوی تمرین یا رشته") }, leadingIcon = { Icon(Icons.Default.Search, null) })
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                categories.forEach { c -> FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) }) }
            }
            Text("نتیجه: ${filtered.size} تمرین", color = Muted, fontSize = 11.sp)
        }
        if (exercises.isEmpty()) {
            EmptyState("فایل کتابخانه خوانده نشد. فایل exercise_bank.json باید داخل assets باشد.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filtered) { e ->
                    CardBox {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth().clickable { expandedId = if (expandedId == e.id) -1 else e.id }) {
                            Surface(color = Color(0xFF26351B), shape = RoundedCornerShape(12.dp), modifier = Modifier.size(42.dp)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.FitnessCenter, null, tint = Neon) } }
                            Column(Modifier.weight(1f)) {
                                Text(e.name, color = MainText, fontWeight = FontWeight.Bold)
                                Text("${e.category} • ${e.level}", color = Neon, fontSize = 11.sp)
                            }
                            Icon(if (expandedId == e.id) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = Muted)
                        }
                        if (expandedId == e.id) {
                            Divider(color = Color(0xFF303A32), modifier = Modifier.padding(vertical = 8.dp))
                            Text("روش اجرا", color = Neon, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(e.instructions, color = MainText, fontSize = 13.sp)
                            Text("وسایل: ${e.equipment}", color = Muted, fontSize = 12.sp)
                            Text("مقدار پیشنهادی: ${e.dose}", color = Muted, fontSize = 12.sp)
                            Text("استراحت: ${e.rest}", color = Muted, fontSize = 12.sp)
                            Text("ایمنی: ${e.safety}", color = Color(0xFFFFD180), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable fun CompetitionScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("vyron_store", Context.MODE_PRIVATE) }
    var exercise by remember { mutableStateOf("اسکوات") }
    var target by remember { mutableIntStateOf(15) }
    var completed by remember { mutableIntStateOf(0) }
    var sessions by remember { mutableIntStateOf(prefs.getInt("challenge_sessions", 0)) }
    var best by remember { mutableIntStateOf(prefs.getInt("challenge_best", 0)) }
    var message by remember { mutableStateOf("یک هدف واقع‌بینانه انتخاب کن و با فرم درست انجامش بده.") }
    val choices = listOf("اسکوات", "شنا روی دیوار", "درازونشست", "پرش جک", "دریبل با توپ")
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Surface(color = Panel, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Surface(color = Color(0xFF29385F), shape = RoundedCornerShape(16.dp), modifier = Modifier.size(54.dp)) {
                            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.TrackChanges, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
                        }
                        Column {
                            Text("چالش شخصی", color = MainText, fontWeight = FontWeight.Black, fontSize = 21.sp)
                            Text("با رکورد دیروزت رقابت کن، نه با بدن دیگران", color = Muted, fontSize = 12.sp)
                        }
                    }
                    Text("نوع چالش", color = MainText, fontWeight = FontWeight.Bold)
                    choices.chunked(3).forEach { group ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            group.forEach { choice ->
                                FilterChip(selected = exercise == choice, onClick = { exercise = choice }, label = { Text(choice, fontSize = 11.sp) })
                            }
                        }
                    }
                    Text("هدف امروز: $target تکرار", color = Neon, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Slider(value = target.toFloat(), onValueChange = { target = it.toInt().coerceIn(5, 40) }, valueRange = 5f..40f, steps = 6)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        IconButton(onClick = { completed = (completed - 1).coerceAtLeast(0) }) { Icon(Icons.Default.RemoveCircleOutline, null, tint = Muted, modifier = Modifier.size(30.dp)) }
                        Text("$completed", color = MainText, fontSize = 42.sp, fontWeight = FontWeight.Black)
                        IconButton(onClick = { completed = (completed + 1).coerceAtMost(target) }) { Icon(Icons.Default.AddCircle, null, tint = Neon, modifier = Modifier.size(34.dp)) }
                        Text("از $target", color = Muted)
                    }
                    LinearProgressIndicator(progress = { (completed.toFloat() / target).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Neon, trackColor = Color(0xFF29324A))
                    Button(onClick = {
                        if (completed >= target) {
                            sessions += 1
                            best = maxOf(best, completed)
                            prefs.edit().putInt("challenge_sessions", sessions).putInt("challenge_best", best).apply()
                            message = "چالش ثبت شد. پیشرفت یعنی استمرار و اجرای درست حرکت."
                            completed = 0
                        } else message = "هنوز به هدفت نرسیدی؛ عجله نکن و فرم درست را حفظ کن."
                    }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Neon)) {
                        Text("ثبت نتیجهٔ چالش", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Text(message, color = Muted, fontSize = 12.sp)
                    Text("اگر درد، سرگیجه یا تنگی نفس غیرعادی داری، چالش را متوقف کن. تعداد بیشتر به‌تنهایی نشانهٔ تمرین بهتر نیست.", color = Accent, fontSize = 11.sp)
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                CardBox { Text("چالش‌های ثبت‌شده", color = Muted, fontSize = 12.sp); Text(sessions.toString(), color = MainText, fontSize = 26.sp, fontWeight = FontWeight.Black) }
                CardBox { Text("بهترین رکورد", color = Muted, fontSize = 12.sp); Text(best.toString(), color = Neon, fontSize = 26.sp, fontWeight = FontWeight.Black) }
            }
        }
    }
}

@Composable fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), content = content)
    }
}
@Composable fun HomeScreen(tasks: List<TaskItem>, workouts: List<WorkoutItem>, steps: Int, sensorAvailable: Boolean,
                           onTasks: () -> Unit, onWorkout: () -> Unit, onFocus: () -> Unit, onCompetition: () -> Unit, onLibrary: () -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(color = Color(0xFF26351B), shape = RoundedCornerShape(18.dp), modifier = Modifier.size(62.dp)) {
                        Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Bolt, null, tint = Neon, modifier = Modifier.size(38.dp)) }
                    }
                    Column(Modifier.weight(1f)) {
                        Text("امروز رو بساز", color = MainText, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("هر روز کمی قوی‌تر از دیروز", color = Neon, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatPill("کارهای مانده", tasks.count { !it.done }.toString(), Icons.Default.CheckCircle, Modifier.weight(1f))
                    StatPill("تمرین‌ها", workouts.size.toString(), Icons.Default.FitnessCenter, Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onCompetition, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Neon)) { Icon(Icons.Default.EmojiEvents, null, tint = Color.White); Spacer(Modifier.width(4.dp)); Text("چالش", color = Color.White) }
                    OutlinedButton(onClick = onLibrary, modifier = Modifier.weight(1f)) { Icon(Icons.Default.MenuBook, null, tint = Neon); Spacer(Modifier.width(4.dp)); Text("۴۰۰ تمرین", color = Neon) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onTasks, modifier = Modifier.weight(1f)) { Text("برنامه روزانه", color = Neon) }
                    OutlinedButton(onClick = onWorkout, modifier = Modifier.weight(1f)) { Text("ثبت تمرین", color = Neon) }
                    OutlinedButton(onClick = onFocus, modifier = Modifier.weight(1f)) { Text("تمرکز", color = Neon) }
                }
            }
        }
        item {
            CardBox {
                Text("قدم‌ها", color = MainText, fontWeight = FontWeight.Bold)
                Text(if(sensorAvailable) "$steps قدم ثبت‌شده در این نوبت اجرا" else "حسگر شمارش قدم روی این گوشی شناسایی نشد.", color = Muted)
                Text("برای عدد دقیق روزانه، نسخه بعدی باید ذخیره روزانه و دسترسی‌ها را تکمیل کند.", color = Muted, fontSize = 11.sp)
            }
        }
        item {
            CardBox {
                Text("یادآوری", color = Neon, fontWeight = FontWeight.Bold)
                Text("قد و وزن در صفحه خانه نمایش داده نمی‌شوند و فقط در پروفایل نگهداری می‌شوند.", color = Muted)
            }
        }
    }
}
@Composable fun TasksScreen(tasks: List<TaskItem>, onAdd: () -> Unit, onToggle: (Int) -> Unit, onDelete: (Int) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("فهرست برنامه‌ها", color = MainText, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Neon)) { Icon(Icons.Default.Add, null, tint = Color.Black); Text("افزودن", color = Color.Black) }
        }
        Spacer(Modifier.height(10.dp))
        if(tasks.isEmpty()) EmptyState("هنوز کاری ثبت نشده؛ اولین کار رو اضافه کن.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tasks.indices.toList()) { idx ->
                val task = tasks[idx]
                Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = task.done, onCheckedChange = { onToggle(idx) }, colors = CheckboxDefaults.colors(checkedColor = Neon))
                        Column(Modifier.weight(1f)) {
                            Text(task.title, color = if(task.done) Muted else MainText, fontWeight = FontWeight.SemiBold)
                            Text(task.kind, color = Muted, fontSize = 12.sp)
                        }
                        IconButton(onClick = { onDelete(idx) }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFFF7777)) }
                    }
                }
            }
        }
    }
}
@Composable fun WorkoutScreen(workouts: List<WorkoutItem>, onAdd: () -> Unit, onStory: () -> Unit, onSmartLock: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("دفتر تمرین", color = MainText, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Neon)) { Icon(Icons.Default.Add, null, tint = Color.Black); Text("ثبت", color = Color.Black) }
        }
        Spacer(Modifier.height(10.dp))
        CardBox {
            Text("قالب استوری", color = Neon, fontWeight = FontWeight.Bold)
            Text("اطلاعات ثبت‌شده را برای آماده‌سازی استوری مرور کن. خروجی تصویر قابل‌اشتراک‌گذاری در نسخه بعد تکمیل می‌شود.", color = Muted, fontSize = 12.sp)
            Button(onClick = onStory, colors = ButtonDefaults.buttonColors(containerColor = Neon)) { Text("نمایش خلاصه آخرین تمرین", color = Color.Black) }
        }
        Spacer(Modifier.height(10.dp))
        CardBox {
            Text("قفل هوشمند تمرین", color = Neon, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("۳۰ اسکوات با بررسی دوربین؛ سپس ۳۰ دقیقه دسترسی به برنامه‌ها. بعد از پایان زمان، محدودیت دوباره فعال می‌شود.", color = Muted, fontSize = 12.sp)
            Button(onClick = onSmartLock, colors = ButtonDefaults.buttonColors(containerColor = Neon)) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = Color.Black)
                Spacer(Modifier.width(6.dp)); Text("شروع اسکوات با دوربین", color = Color.Black)
            }
        }
        Spacer(Modifier.height(10.dp))
        if(workouts.isEmpty()) EmptyState("هنوز تمرینی ثبت نشده.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(workouts.reversed()) { w ->
                CardBox {
                    Text(w.title, color = MainText, fontWeight = FontWeight.Bold)
                    Text("${w.duration} دقیقه • ${w.date}", color = Neon, fontSize = 12.sp)
                    if(w.notes.isNotBlank()) Text(w.notes, color = Muted)
                }
            }
        }
    }
}
@Composable fun FocusScreen(minutes: Int, running: Boolean, onMinutes: (Int) -> Unit, onToggle: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        CardBox {
            Text("زمان‌سنج تمرکز", color = MainText, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text("$minutes دقیقه", color = Neon, fontSize = 34.sp, fontWeight = FontWeight.Black)
            Text(if(running) "جلسه علامت‌گذاری شده به‌عنوان فعال است؛ شمارش معکوس پس‌زمینه هنوز پیاده‌سازی نشده." else "زمان جلسه را انتخاب کن.", color = Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(15, 25, 45).forEach { n ->
                    FilterChip(selected = minutes == n, onClick = { onMinutes(n) }, label = { Text("$n دقیقه") })
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onToggle, colors = ButtonDefaults.buttonColors(containerColor = Neon)) {
                Text(if(running) "پایان جلسه" else "شروع جلسه", color = Color.Black)
            }
        }
        CardBox {
            Text("محدودسازی برنامه‌ها", color = MainText, fontWeight = FontWeight.Bold)
            Text("قفل برنامه‌ها باید از مسیر تنظیمات خود اندروید مجوز بگیرد؛ وی‌رون وضعیت را بررسی می‌کند و تو را مستقیم به صفحهٔ لازم می‌برد.", color = Muted, fontSize = 12.sp)
        }
    }
}
@Composable fun ProfileScreen(profile: Profile, phoneOwner: String, onSave: (Profile) -> Unit, onChangePhoneOwner: () -> Unit, onNotifySettings: () -> Unit, onBlockSettings: () -> Unit, onParentSettings: () -> Unit, onStep: () -> Unit, sensorAvailable: Boolean) {
    var age by remember(profile) { mutableStateOf(profile.age) }
    var height by remember(profile) { mutableStateOf(profile.height) }
    var weight by remember(profile) { mutableStateOf(profile.weight) }
    var goal by remember(profile) { mutableStateOf(profile.goal) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Surface(color = Color(0xFF172119), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Surface(color = Color(0xFF26351B), shape = RoundedCornerShape(22.dp), modifier = Modifier.size(76.dp)) {
                        Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Neon, modifier = Modifier.size(48.dp)) }
                    }
                    Column(Modifier.weight(1f)) {
                        Text("پروفایل ورزشکار", color = MainText, fontWeight = FontWeight.Black, fontSize = 20.sp)
                        Text(goal.ifBlank { "هدف بعدی‌ات را مشخص کن" }, color = Neon, fontSize = 12.sp)
                        Text("اطلاعاتت را ثبت کن تا پیشرفتت را پیگیری کنی", color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProfileMetric("سن", age.ifBlank { "—" }, Icons.Default.Cake, Modifier.weight(1f))
                ProfileMetric("قد", height.ifBlank { "—" }, Icons.Default.Straighten, Modifier.weight(1f))
                ProfileMetric("وزن", weight.ifBlank { "—" }, Icons.Default.FitnessCenter, Modifier.weight(1f))
            }
        }
        item {
            CardBox {
                Text("مالک و شیوه استفاده از گوشی", color = Neon, fontWeight = FontWeight.Bold)
                Text("انتخاب فعلی: ${phoneOwner.ifBlank { "تعیین نشده" }}", color = Muted)
                Text("تغییر این نقش با رمز مدیر انجام می‌شود.", color = Muted, fontSize = 12.sp)
                OutlinedButton(onClick = onChangePhoneOwner) { Text("تغییر انتخاب", color = Neon) }
            }
        }
        item { InputField("سن", age, { age = it }, "سال", KeyboardType.Number) }
        item { InputField("قد", height, { height = it }, "سانتی‌متر یا متر", KeyboardType.Decimal) }
        item { InputField("وزن", weight, { weight = it }, "کیلوگرم", KeyboardType.Decimal) }
        item { InputField("هدف اصلی", goal, { goal = it }, "مثلاً پیشرفت در فوتبال", KeyboardType.Text) }
        item { Button(onClick = { onSave(Profile(age, height, weight, goal)) }, colors = ButtonDefaults.buttonColors(containerColor = Neon)) { Text("ذخیره پروفایل", color = Color.Black) } }
        item {
            CardBox {
                Text("مجوزها و امکانات", color = Neon, fontWeight = FontWeight.Bold)
                Text("حسگر قدم: ${if(sensorAvailable) "موجود" else "شناسایی نشد"}", color = Muted)
                Button(onClick = onStep) { Text("فعال‌کردن ثبت قدم") }
                OutlinedButton(onClick = onNotifySettings) { Text("بررسی دسترسی اعلان‌ها", color = Neon) }
                OutlinedButton(onClick = onBlockSettings) { Text("تنظیم قفل برنامه‌ها", color = Neon) }
                OutlinedButton(onClick = onParentSettings) { Text("🔐 حالت والدین", color = Neon) }
                Text("اعلان‌ها فقط پس از فعال‌سازی دستی دسترسی خوانده می‌شوند. این قابلیت تاریخچه کامل پیام‌رسان‌ها را باز نمی‌کند.", color = Muted, fontSize = 11.sp)
                Text("محدودسازی تمرکز با دسترسی دسترس‌پذیری اختیاری است و با خاموش‌کردن مجوز یا راه‌اندازی دوباره دستگاه قابل دورزدن است.", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

/** A local manager-PIN gate. This prevents casual role switching inside VYRON,
 * but it is not a system-level tamper-proof parental control. */
@Composable fun ManagerAuthDialog(
    canDismiss: Boolean,
    onDismiss: () -> Unit,
    onAuthorized: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("vyron_store", Context.MODE_PRIVATE) }
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var failedAttempts by remember { mutableIntStateOf(0) }
    var lockoutUntil by remember { mutableLongStateOf(prefs.getLong("manager_lockout_until", 0L)) }
    val needsSetup = remember { prefs.getString("parent_pin_hash", null).isNullOrBlank() }
    val locked = System.currentTimeMillis() < lockoutUntil

    fun hashPin(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    AlertDialog(
        onDismissRequest = { if (canDismiss) onDismiss() },
        title = { Text(if (needsSetup) "راه‌اندازی دسترسی مدیر" else "تأیید مدیر VYRON", color = Neon, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (needsSetup) "پیش از انتخاب نقش گوشی، مدیر باید یک رمز ۴ تا ۸ رقمی تعیین کند. این مرحله را خود والد انجام دهد؛ برنامه نمی‌تواند هویت والد را به‌طور مستقل تشخیص دهد."
                    else "برای تغییر نقش گوشی، رمز مدیر لازم است.",
                    color = Muted, fontSize = 12.sp
                )
                if (needsSetup) {
                    OutlinedTextField(value = pin, onValueChange = { if (it.length <= 8 && it.all(Char::isDigit)) pin = it },
                        label = { Text("رمز مدیر") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
                    OutlinedTextField(value = confirmPin, onValueChange = { if (it.length <= 8 && it.all(Char::isDigit)) confirmPin = it },
                        label = { Text("تکرار رمز مدیر") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
                } else {
                    OutlinedTextField(value = pin, onValueChange = { if (it.length <= 8 && it.all(Char::isDigit)) pin = it },
                        label = { Text("رمز مدیر") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
                }
                if (locked) Text("به‌دلیل چند تلاش ناموفق، موقتاً قفل شده است.", color = Color(0xFFFF8A80), fontSize = 12.sp)
                if (message.isNotBlank()) Text(message, color = Color(0xFFFF8A80), fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(enabled = !locked, onClick = {
                if (needsSetup) {
                    if (pin.length !in 4..8) message = "رمز باید بین ۴ تا ۸ رقم باشد."
                    else if (pin != confirmPin) message = "دو رمز یکسان نیستند."
                    else {
                        prefs.edit().putString("parent_pin_hash", hashPin(pin))
                            .putInt("manager_failed_attempts", 0).putLong("manager_lockout_until", 0L).apply()
                        onAuthorized()
                    }
                } else {
                    val expected = prefs.getString("parent_pin_hash", "") ?: ""
                    if (pin.isNotBlank() && hashPin(pin) == expected) {
                        prefs.edit().putInt("manager_failed_attempts", 0).putLong("manager_lockout_until", 0L).apply()
                        onAuthorized()
                    } else {
                        failedAttempts += 1
                        val total = prefs.getInt("manager_failed_attempts", 0) + 1
                        prefs.edit().putInt("manager_failed_attempts", total).apply()
                        pin = ""
                        if (total >= 5) {
                            lockoutUntil = System.currentTimeMillis() + 30_000L
                            prefs.edit().putLong("manager_lockout_until", lockoutUntil).putInt("manager_failed_attempts", 0).apply()
                            message = "۵ تلاش ناموفق؛ ۳۰ ثانیه صبر کن."
                        } else message = "رمز نادرست است. تلاش باقی‌مانده تا قفل موقت: ${5 - total}"
                    }
                }
            }) { Text(if (needsSetup) "ثبت رمز مدیر" else "تأیید و ادامه", color = Neon) }
        },
        dismissButton = { if (canDismiss) TextButton(onClick = onDismiss) { Text("بستن", color = Muted) } },
        containerColor = Panel,
        titleContentColor = MainText,
        textContentColor = MainText
    )
}

@Composable fun PhoneOwnerDialog(
    currentOwner: String,
    canDismiss: Boolean,
    onDismiss: () -> Unit,
    onChoose: (String) -> Unit
) {
    var selectedOwner by remember(currentOwner) { mutableStateOf(currentOwner) }
    val choices = listOf(
        "گوشی خودم است" to "خودم استفاده می‌کنم",
        "گوشی فرزندم است" to "فرزندم استفاده می‌کند",
        "گوشی مشترک است" to "گوشی مشترک خانوادگی است"
    )
    AlertDialog(
        onDismissRequest = { if (canDismiss) onDismiss() },
        title = { Text("VYRON را برای چه کسی تنظیم کنیم؟", color = Neon, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("این انتخاب فقط شخصی‌سازی تجربه را مشخص می‌کند؛ به‌تنهایی قفل یا نظارت سیستمی فعال نمی‌کند.", color = Muted, fontSize = 12.sp)
                choices.forEach { (value, label) ->
                    Surface(
                        color = if (selectedOwner == value) Color(0xFF26351B) else Panel,
                        shape = RoundedCornerShape(12.dp),
                        onClick = { selectedOwner = value }
                    ) {
                        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = selectedOwner == value, onClick = { selectedOwner = value })
                            Spacer(Modifier.width(6.dp))
                            Text(label, color = MainText)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { if (selectedOwner.isNotBlank()) onChoose(selectedOwner) }, enabled = selectedOwner.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Neon)) {
                Text("ذخیره و ادامه", color = Color.Black)
            }
        },
        dismissButton = { if (canDismiss) TextButton(onClick = onDismiss) { Text("انصراف", color = Muted) } },
        containerColor = Panel,
        titleContentColor = MainText,
        textContentColor = MainText
    )
}

@Composable fun ParentControlsDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("vyron_store", Context.MODE_PRIVATE) }
    var pin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var authenticated by remember { mutableStateOf(false) }
    var setupMode by remember { mutableStateOf(prefs.getString("parent_pin_hash", null) == null) }
    var pauseMinutes by remember { mutableIntStateOf(15) }
    val pauseUntil = prefs.getLong("parent_pause_until", 0L)
    val pauseActive = System.currentTimeMillis() < pauseUntil

    fun hashPin(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("VYRON · حالت والدین", color = Neon) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (setupMode) {
                    Text("والدین: یک رمز ۴ تا ۸ رقمی بسازید و آن را محرمانه نگه دارید.", color = Muted, fontSize = 12.sp)
                    OutlinedTextField(value = newPin, onValueChange = { if (it.length <= 8 && it.all(Char::isDigit)) newPin = it }, label = { Text("رمز جدید والدین") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
                    OutlinedTextField(value = confirmPin, onValueChange = { if (it.length <= 8 && it.all(Char::isDigit)) confirmPin = it }, label = { Text("تکرار رمز") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
                    if (message.isNotBlank()) Text(message, color = Neon, fontSize = 12.sp)
                } else if (!authenticated) {
                    Text("برای مدیریت محدودیت‌ها، رمز والدین را وارد کنید.", color = Muted, fontSize = 12.sp)
                    OutlinedTextField(value = pin, onValueChange = { if (it.length <= 8 && it.all(Char::isDigit)) pin = it }, label = { Text("رمز والدین") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
                    if (message.isNotBlank()) Text(message, color = Color(0xFFFF8A80), fontSize = 12.sp)
                } else {
                    Text("دسترسی والدین فعال شد.", color = Neon, fontWeight = FontWeight.Bold)
                    Text(if (pauseActive) "محدودیت‌ها موقتاً متوقف‌اند." else "محدودیت‌ها در حال اجرا هستند.", color = Muted, fontSize = 12.sp)
                    Text("مدت توقف:", color = MainText)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(15, 60, 120).forEach { mins ->
                            FilterChip(selected = pauseMinutes == mins, onClick = { pauseMinutes = mins }, label = { Text(if (mins == 120) "۲ ساعت" else if (mins == 60) "۱ ساعت" else "۱۵ دقیقه") })
                        }
                    }
                    Text("این توقف فقط سرویس محدودسازی VYRON را متوقف می‌کند؛ قفل سیستم اندروید را تغییر نمی‌دهد.", color = Muted, fontSize = 11.sp)
                }
            }
        },
        confirmButton = {
            if (setupMode) TextButton(onClick = {
                if (newPin.length < 4) message = "رمز باید حداقل ۴ رقم باشد."
                else if (newPin != confirmPin) message = "دو رمز یکسان نیستند."
                else {
                    prefs.edit().putString("parent_pin_hash", hashPin(newPin)).apply()
                    setupMode = false; authenticated = true; message = ""
                }
            }) { Text("ثبت رمز", color = Neon) }
            else if (!authenticated) TextButton(onClick = {
                val stored = prefs.getString("parent_pin_hash", "") ?: ""
                if (pin.isNotEmpty() && hashPin(pin) == stored) { authenticated = true; message = "" }
                else message = "رمز نادرست است."
            }) { Text("ورود", color = Neon) }
            else TextButton(onClick = {
                prefs.edit().putLong("parent_pause_until", System.currentTimeMillis() + pauseMinutes * 60_000L).apply()
                onDismiss()
            }) { Text("توقف محدودیت‌ها", color = Neon) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("بستن", color = Muted) } }
    )
}

@Composable fun InputField(label: String, value: String, onChange: (String) -> Unit, hint: String, type: KeyboardType) {
    OutlinedTextField(value = value, onValueChange = onChange, label = { Text(label) }, placeholder = { Text(hint) },
        modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = type),
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Neon, focusedLabelColor = Neon, cursorColor = Neon))
}
@Composable fun TaskDialog(onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var title by remember { mutableStateOf("") }; var kind by remember { mutableStateOf("درس") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("کار جدید") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            InputField("عنوان", title, { title = it }, "مثلاً ریاضی فصل اول", KeyboardType.Text)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("درس", "تکلیف", "امتحان", "شخصی").forEach { FilterChip(selected = kind == it, onClick = { kind = it }, label = { Text(it) }) }
            }
        } },
        confirmButton = { TextButton(onClick = { if(title.isNotBlank()) onSave(title.trim(), kind) }) { Text("ذخیره", color = Neon) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("لغو") } })
}
@Composable fun WorkoutDialog(onDismiss: () -> Unit, onSave: (String, Int, String) -> Unit) {
    var title by remember { mutableStateOf("فوتبال") }; var duration by remember { mutableStateOf("30") }; var notes by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("ثبت تمرین") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            InputField("نوع تمرین", title, { title = it }, "فوتبال، قدرتی، رزمی...", KeyboardType.Text)
            InputField("مدت (دقیقه)", duration, { duration = it }, "30", KeyboardType.Number)
            InputField("جزئیات", notes, { notes = it }, "حرکات و تعداد تکرارها", KeyboardType.Text)
        } },
        confirmButton = { TextButton(onClick = { val d = duration.toIntOrNull(); if(title.isNotBlank() && d != null && d > 0) onSave(title.trim(), d, notes.trim()) }) { Text("ذخیره", color = Neon) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("لغو") } })
}
@Composable fun StoryDialog(workout: WorkoutItem?, onDismiss: () -> Unit, onExport: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("خلاصه تمرین") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if(workout == null) Text("هنوز تمرینی ثبت نشده.")
            else {
                Text(workout.title, color = Neon, fontWeight = FontWeight.Bold)
                Text("مدت: ${workout.duration} دقیقه")
                Text("تاریخ: ${workout.date}")
                Text("جزئیات: ${workout.notes.ifBlank { "جزئیاتی ثبت نشده" }}")
            }
            Text("تصویر ۱۰۸۰×۱۹۲۰ ساخته می‌شود. شکل عضلات تزئینی است و از بدن واقعی یا رشد عضله اندازه‌گیری نمی‌کند.", color = Muted, fontSize = 12.sp)
        } },
        confirmButton = { Row {
            TextButton(onClick = onExport) { Text("ذخیره تصویر", color = Neon) }
            TextButton(onClick = onDismiss) { Text("بستن", color = Neon) }
        } })
}
@Composable fun BlockAppsDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("vyron_store", Context.MODE_PRIVATE) }
    var search by remember { mutableStateOf("") }
    var studentDefaultLock by remember { mutableStateOf(prefs.getBoolean("student_default_lock", false)) }
    var selected by remember {
        mutableStateOf(try { val a = JSONArray(prefs.getString("blocked_packages", "[]") ?: "[]"); (0 until a.length()).map { a.optString(it) }.toSet() } catch (_: Exception) { emptySet() })
    }
    val accessibilityServices = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
    val blockerEnabled = accessibilityServices.contains("VyronBlockerService", ignoreCase = true)
    val apps = remember {
        try {
            context.packageManager.getInstalledApplications(0)
                .filter { it.packageName != context.packageName }
                .map { it.packageName to context.packageManager.getApplicationLabel(it).toString() }
                .sortedBy { it.second.lowercase(Locale.ROOT) }
        } catch (_: Exception) { emptyList() }
    }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("برنامه‌های مزاحم") },
        text = {
            Column {
                Text("حالت دانش‌آموزی: همهٔ برنامه‌ها به‌طور پیش‌فرض محدود می‌شوند، به‌جز گوگل، ماشین‌حساب و ابزارهای هوش مصنوعی آموزشی.", color = Muted, fontSize = 12.sp)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("قفل پیش‌فرض همهٔ برنامه‌ها", color = MainText, fontWeight = FontWeight.SemiBold)
                        Text("ابزارهای درسی و برنامه‌های ضروری آزاد می‌مانند", color = Muted, fontSize = 11.sp)
                    }
                    Switch(checked = studentDefaultLock, onCheckedChange = { studentDefaultLock = it })
                }
                Surface(color = if (blockerEnabled) Color(0xFF20371D) else Color(0xFF3A2918), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(if (blockerEnabled) "● سرویس محدودسازی روشن است" else "● سرویس خاموش است؛ فعلاً هیچ برنامه‌ای قفل نمی‌شود", color = if (blockerEnabled) Neon else Color(0xFFFFC078), modifier = Modifier.padding(10.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("جست‌وجوی برنامه") }, singleLine = true)
                Spacer(Modifier.height(6.dp))
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(apps.filter { it.second.contains(search, true) || it.first.contains(search, true) }.take(150)) { app ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = app.first in selected, onCheckedChange = { checked -> selected = if (checked) selected + app.first else selected - app.first })
                            Column(Modifier.weight(1f)) {
                                Text(app.second, color = MainText, fontSize = 14.sp)
                                Text(app.first, color = Muted, fontSize = 9.sp)
                            }
                        }
                    }
                }
                Text("پس از ذخیره، برای اعمال محدودیت باید سرویس VYRON را در تنظیمات دسترس‌پذیری اندروید روشن کنی.", color = Muted, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = {
            val a = JSONArray(); selected.forEach { a.put(it) }
            prefs.edit()
                .putString("blocked_packages", a.toString())
                .putBoolean("student_default_lock", studentDefaultLock)
                .apply()
            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            onDismiss()
        }) { Text("ذخیره و بازکردن تنظیمات", color = Neon) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("لغو", color = Neon) } })
}

@Composable fun EmptyState(text: String) {
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Text(text, color = Muted, modifier = Modifier.padding(16.dp))
    }
}
