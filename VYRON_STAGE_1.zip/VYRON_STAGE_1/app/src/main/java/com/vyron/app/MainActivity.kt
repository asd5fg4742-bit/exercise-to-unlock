package com.vyron.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val BG=Color(0xFF090B0A)
private val PANEL=Color(0xFF151916)
private val LIME=Color(0xFFB7F34A)
private val MUTED=Color(0xFF9DA79F)
private val FG=Color(0xFFF5F7F4)

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  val prefs=getSharedPreferences("vyron_settings",Context.MODE_PRIVATE)
  setContent {
   var language by remember { mutableStateOf(prefs.getString("language",null)) }
   var choosing by remember { mutableStateOf(language==null) }
   MaterialTheme(colorScheme=darkColorScheme(primary=LIME,background=BG,surface=PANEL,onPrimary=BG,onBackground=FG,onSurface=FG)){
    if(choosing || language==null) LanguagePicker(language ?: deviceLanguage()) { chosen ->
     prefs.edit().putString("language",chosen).apply(); language=chosen; choosing=false
    } else CompositionLocalProvider(LocalLayoutDirection provides if(language=="fa"||language=="ar") LayoutDirection.Rtl else LayoutDirection.Ltr) {
     Dashboard(language!!) { choosing=true }
    }
   }
  }
 }
}
data class Lang(val code:String,val native:String,val english:String)
private val langs=listOf(Lang("fa","فارسی","Persian"),Lang("en","English","English"),Lang("ar","العربية","Arabic"),Lang("tr","Türkçe","Turkish"),Lang("ru","Русский","Russian"))
private fun deviceLanguage():String { val c=Locale.getDefault().language; return if(langs.any{it.code==c}) c else "en" }
private fun s(l:String,fa:String,en:String,ar:String,tr:String,ru:String)=when(l){"fa"->fa;"ar"->ar;"tr"->tr;"ru"->ru;else->en}

@Composable fun LanguagePicker(initial:String,onDone:(String)->Unit){
 var selected by remember { mutableStateOf(initial) }
 CompositionLocalProvider(LocalLayoutDirection provides if(selected=="fa"||selected=="ar") LayoutDirection.Rtl else LayoutDirection.Ltr){
  Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF142016),BG,Color(0xFF070807)))).padding(24.dp),verticalArrangement=Arrangement.SpaceBetween){
   Column {
    Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(LIME),contentAlignment=Alignment.Center){Icon(Icons.Default.Bolt,null,tint=BG,modifier=Modifier.size(30.dp))};Spacer(Modifier.width(12.dp));Text("VYRON",color=LIME,fontSize=27.sp,fontWeight=FontWeight.Black,letterSpacing=2.sp)}
    Spacer(Modifier.height(38.dp))
    Text(s(selected,"زبان برنامه را انتخاب کن","Choose your language","اختر لغة التطبيق","Uygulama dilini seç","Выберите язык"),color=FG,fontSize=28.sp,fontWeight=FontWeight.ExtraBold,lineHeight=36.sp)
    Spacer(Modifier.height(9.dp))
    Text(s(selected,"زبان گوشی شناسایی شده؛ انتخاب نهایی با خودت است.","Your phone language was detected. The final choice is yours.","تم اكتشاف لغة هاتفك، والاختيار النهائي لك.","Telefon dili algılandı. Son seçim senin.","Язык телефона определён. Окончательный выбор за вами."),color=MUTED,fontSize=14.sp,lineHeight=22.sp)
    Spacer(Modifier.height(16.dp))
    Surface(color=Color(0xFF202B1A),shape=RoundedCornerShape(14.dp)){Row(Modifier.fillMaxWidth().padding(13.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Language,null,tint=LIME);Spacer(Modifier.width(10.dp));Column{Text(s(selected,"زبان پیشنهادی گوشی","Suggested phone language","لغة الهاتف المقترحة","Önerilen telefon dili","Предлагаемый язык телефона"),color=FG,fontWeight=FontWeight.SemiBold);Text(langs.first{it.code==initial}.native,color=LIME,fontSize=13.sp)}}}
    Spacer(Modifier.height(18.dp))
    langs.forEach { lang ->
     val active=selected==lang.code
     Row(Modifier.fillMaxWidth().padding(vertical=4.dp).clip(RoundedCornerShape(15.dp)).background(if(active)Color(0xFF29351F) else PANEL).border(if(active)1.5.dp else 1.dp,if(active)LIME else Color(0xFF272D28),RoundedCornerShape(15.dp)).clickable{selected=lang.code}.padding(horizontal=15.dp,vertical=12.dp),verticalAlignment=Alignment.CenterVertically){
      Column(Modifier.weight(1f)){Text(lang.native,color=FG,fontSize=17.sp,fontWeight=FontWeight.Bold);Text(lang.english,color=MUTED,fontSize=12.sp)}
      if(active) Icon(Icons.Default.CheckCircle,null,tint=LIME) else Box(Modifier.size(20.dp).border(1.dp,MUTED,CircleShape))
     }
    }
   }
   Button(onClick={onDone(selected)},modifier=Modifier.fillMaxWidth().height(55.dp),shape=RoundedCornerShape(17.dp),colors=ButtonDefaults.buttonColors(containerColor=LIME,contentColor=BG)){
    Text(s(selected,"شروع با این زبان","Continue","متابعة","Devam et","Продолжить"),fontSize=16.sp,fontWeight=FontWeight.ExtraBold);Spacer(Modifier.width(8.dp));Icon(Icons.Default.ArrowForward,null)
   }
  }
 }
}
@Composable fun Dashboard(lang:String,onLanguage:()->Unit){
 var tab by remember{mutableIntStateOf(0)}
 var category by remember{mutableIntStateOf(0)}
 val categories=listOf(s(lang,"همه","All","الكل","Tümü","Все"),s(lang,"قدرتی","Strength","قوة","Güç","Сила"),s(lang,"فوتبال","Football","كرة القدم","Futbol","Футбол"),s(lang,"هوازی","Cardio","كارديو","Kardiyo","Кардио"))
 Scaffold(containerColor=BG,bottomBar={NavigationBar(containerColor=Color(0xFF111512),tonalElevation=0.dp){val tabs=listOf(s(lang,"خانه","Home","الرئيسية","Ana sayfa","Главная") to Icons.Default.Home,s(lang,"آمار","Stats","الإحصاءات","İstatistik","Статистика") to Icons.Default.Insights,s(lang,"تمرین","Workout","تمرين","Antrenman","Тренировка") to Icons.Default.FitnessCenter,s(lang,"پروفایل","Profile","الملف","Profil","Профиль") to Icons.Default.Person);tabs.forEachIndexed{i,t->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(t.second,t.first)},label={Text(t.first,fontSize=10.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=LIME,selectedTextColor=LIME,indicatorColor=Color(0xFF2B381F),unselectedIconColor=MUTED,unselectedTextColor=MUTED))}}}){pad->
  Column(Modifier.fillMaxSize().padding(pad).padding(horizontal=18.dp)){
   Spacer(Modifier.height(13.dp))
   Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(42.dp).clip(CircleShape).background(Brush.linearGradient(listOf(LIME,Color(0xFF80DDB1)))),contentAlignment=Alignment.Center){Icon(Icons.Default.Bolt,null,tint=BG,modifier=Modifier.size(26.dp))};Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text("VYRON",color=LIME,fontSize=21.sp,fontWeight=FontWeight.Black,letterSpacing=1.5.sp);Text(s(lang,"قدرتت را بساز.","Build your edge.","اصنع قوتك.","Gücünü oluştur.","Создавай свою силу."),color=MUTED,fontSize=12.sp)};IconButton(onClick=onLanguage){Icon(Icons.Default.Language,null,tint=FG)};IconButton(onClick={tab=3}){Icon(Icons.Default.AccountCircle,null,tint=FG,modifier=Modifier.size(27.dp))}}
   Spacer(Modifier.height(19.dp))
   Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(s(lang,"برنامه امروز","Today's plan","خطة اليوم","Bugünün planı","План на сегодня"),color=FG,fontSize=24.sp,fontWeight=FontWeight.ExtraBold);Text(s(lang,"یک قدم بهتر از دیروز.","One step better than yesterday.","خطوة أفضل من الأمس.","Dünden bir adım ileri.","На шаг лучше, чем вчера."),color=MUTED,fontSize=13.sp)};Surface(color=PANEL,shape=RoundedCornerShape(14.dp)){Column(Modifier.padding(horizontal=12.dp,vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.LocalFireDepartment,null,tint=LIME);Text("0",color=LIME,fontSize=18.sp,fontWeight=FontWeight.Bold);Text(s(lang,"روز پیاپی","streak","أيام متتالية","gün seri","дней подряд"),color=MUTED,fontSize=9.sp)}}}
   Spacer(Modifier.height(17.dp))
   Box(Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(LIME,Color(0xFF7CCB70),Color(0xFF315B3D))))){
    Column(Modifier.align(Alignment.CenterStart).padding(start=18.dp,end=105.dp)){Text(s(lang,"چالش امروز","DAILY CHALLENGE","تحدي اليوم","GÜNLÜK MEYDAN OKUMA","ВЫЗОВ ДНЯ"),color=BG.copy(alpha=.65f),fontSize=10.sp,fontWeight=FontWeight.Black,letterSpacing=1.sp);Spacer(Modifier.height(5.dp));Text(s(lang,"از خودت جلو بزن","Beat yesterday.","تجاوز إنجاز الأمس","Dünü geride bırak","Превзойди вчерашнего себя"),color=BG,fontSize=23.sp,fontWeight=FontWeight.Black,lineHeight=27.sp);Spacer(Modifier.height(7.dp));Text(s(lang,"۲۰ دقیقه حرکت؛ همین امروز.","20 minutes of movement. Today.","٢٠ دقيقة من الحركة اليوم.","20 dakika hareket. Bugün.","20 минут движения. Сегодня."),color=BG.copy(alpha=.8f),fontSize=11.sp);Spacer(Modifier.height(10.dp));Surface(color=BG,shape=RoundedCornerShape(12.dp),modifier=Modifier.clickable{tab=2}){Row(Modifier.padding(horizontal=12.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){Text(s(lang,"شروع تمرین","Start workout","ابدأ التمرين","Antrenmana başla","Начать тренировку"),color=LIME,fontSize=12.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.width(5.dp));Icon(Icons.Default.ArrowForward,null,tint=LIME,modifier=Modifier.size(15.dp))}}}
    Icon(Icons.Default.FitnessCenter,null,tint=BG.copy(alpha=.16f),modifier=Modifier.align(Alignment.CenterEnd).padding(end=11.dp).size(95.dp))
   }
   Spacer(Modifier.height(19.dp))
   Row(verticalAlignment=Alignment.CenterVertically){Text(s(lang,"برنامه تمرین","Workout plans","خطط التمرين","Antrenman planları","Планы тренировок"),color=FG,fontSize=18.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));Text(s(lang,"مشاهده همه","View all","عرض الكل","Tümünü gör","Все"),color=LIME,fontSize=12.sp)}
   Spacer(Modifier.height(10.dp))
   Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){categories.forEachIndexed{i,c->Surface(color=if(category==i)LIME else PANEL,shape=RoundedCornerShape(50),modifier=Modifier.clickable{category=i}){Text(c,color=if(category==i)BG else MUTED,modifier=Modifier.padding(horizontal=16.dp,vertical=9.dp),fontSize=12.sp,fontWeight=FontWeight.SemiBold)}}}
   Spacer(Modifier.height(12.dp))
   Row(horizontalArrangement=Arrangement.spacedBy(11.dp)){WorkoutCard(Modifier.weight(1f),Icons.Default.FitnessCenter,LIME,s(lang,"قدرت و عضله","Strength & muscle","القوة والعضلات","Güç ve kas","Сила и мышцы"),s(lang,"۱۲ حرکت پیشنهادی","12 suggested moves","١٢ حركة مقترحة","12 önerilen hareket","12 упражнений"));WorkoutCard(Modifier.weight(1f),Icons.Default.SportsSoccer,Color(0xFF80DDB1),s(lang,"زمین فوتبال","Football field","ملعب كرة القدم","Futbol sahası","Футбольное поле"),s(lang,"سرعت و کنترل توپ","Speed & ball control","السرعة والتحكم بالكرة","Hız ve top kontrolü","Скорость и контроль мяча"))}
   Spacer(Modifier.height(18.dp))
   Text(s(lang,"خلاصه فعالیت","Activity snapshot","ملخص النشاط","Aktivite özeti","Сводка активности"),color=FG,fontSize=18.sp,fontWeight=FontWeight.Bold)
   Spacer(Modifier.height(9.dp))
   Row(horizontalArrangement=Arrangement.spacedBy(9.dp)){StatCard(Modifier.weight(1f),Icons.Default.LocalFireDepartment,"0",s(lang,"کالری","Calories","سعرات","Kalori","Калории"));StatCard(Modifier.weight(1f),Icons.Default.Timer,"0 min",s(lang,"زمان تمرین","Workout time","وقت التمرين","Antrenman süresi","Время тренировки"));StatCard(Modifier.weight(1f),Icons.Default.CheckCircle,"0",s(lang,"جلسه","Sessions","جلسات","Seans","Сессии"))}
   Spacer(Modifier.height(12.dp))
  }
 }
}
@Composable fun WorkoutCard(modifier:Modifier,icon:ImageVector,tint:Color,title:String,subtitle:String){Surface(modifier.height(128.dp),color=PANEL,shape=RoundedCornerShape(19.dp)){Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.SpaceBetween){Box(Modifier.size(37.dp).clip(RoundedCornerShape(12.dp)).background(tint.copy(alpha=.15f)),contentAlignment=Alignment.Center){Icon(icon,null,tint=tint,modifier=Modifier.size(23.dp))};Column{Text(title,color=FG,fontSize=13.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis);Spacer(Modifier.height(3.dp));Text(subtitle,color=MUTED,fontSize=10.sp,maxLines=2,overflow=TextOverflow.Ellipsis)}}}}
@Composable fun StatCard(modifier:Modifier,icon:ImageVector,value:String,label:String){Surface(modifier.height(88.dp),color=PANEL,shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(10.dp),verticalArrangement=Arrangement.SpaceBetween){Icon(icon,null,tint=LIME,modifier=Modifier.size(17.dp));Text(value,color=FG,fontSize=15.sp,fontWeight=FontWeight.ExtraBold);Text(label,color=MUTED,fontSize=10.sp,maxLines=1,overflow=TextOverflow.Ellipsis)}}}
