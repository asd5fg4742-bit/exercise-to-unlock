package com.amirali.project

data class Exercise(val name: String, val sets: Int, val reps: Int, val seconds: Int, val muscles: Set<String>, val mainMuscles: Set<String> = muscles)

object WorkoutData {
    val muscleNames = mapOf(
        "chest" to "سینه", "triceps" to "پشت بازو", "frontShoulder" to "سرشانه جلویی",
        "core" to "عضلات مرکزی", "quads" to "چهارسر ران", "glutes" to "باسن",
        "hamstrings" to "همسترینگ", "lats" to "پشتی بزرگ", "biceps" to "جلو بازو", "forearms" to "ساعد", "upperBack" to "پشت بالایی"
    )
    val catalog = listOf(
        Exercise("شنا سوئدی", 2, 6, 0, setOf("chest", "triceps", "frontShoulder", "core"), setOf("chest")),
        Exercise("اسکوات", 2, 10, 0, setOf("quads", "glutes", "hamstrings", "core"), setOf("quads", "glutes")),
        Exercise("پلانک", 2, 0, 15, setOf("core")),
        Exercise("تمرین کنترل توپ", 3, 0, 60, setOf("quads", "hamstrings", "core")),
        Exercise("کشش و ریکاوری", 1, 0, 300, emptySet())
    )
    fun today(): List<Exercise> = when ((java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_WEEK) + 5) % 3) {
        0 -> listOf(catalog[0], catalog[1], catalog[2])
        1 -> listOf(catalog[3], catalog[4])
        else -> listOf(catalog[2], catalog[4])
    }
}
