package com.amirali.project

import android.app.*
import android.content.*
import android.graphics.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("amirali", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private val selected = mutableSetOf<String>()
    private val exercises = WorkoutData.today()
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); selected.addAll(prefs.getStringSet("selected_apps", emptySet()) ?: emptySet()); showHome() }
    private fun base(title: String): LinearLayout {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 20, 22, 20); layoutDirection = View.LAYOUT_DIRECTION_RTL; setBackgroundColor(Color.rgb(16,17,22)) }
        val sc = ScrollView(this); sc.addView(root); setContentView(sc)
        root.addView(TextView(this).apply { text = title; textSize = 26f; setTextColor(Color.rgb(255,122,24)); gravity = Gravity.RIGHT; setPadding(0,8,0,18) })
        return root
    }
    private fun label(text: String, size: Float = 16f) { root.addView(TextView(this).apply { this.text=text; textSize=size; setTextColor(Color.WHITE); gravity=Gravity.RIGHT; setPadding(0,8,0,8) }) }
    private fun button(text: String, action: () -> Unit) { root.addView(Button(this).apply { this.text=text; setOnClickListener { action() } }) }
    private fun showHome() {
        base("پروژه امیرعلی")
        label("اول تمرین، بعد سرگرمی. این نسخه اولیه است و آمار فقط از چیزهایی می‌آید که ثبت می‌کنی.")
        label("تمرین پیشنهادی امروز", 20f)
        exercises.forEach { e -> label("• ${e.name}  |  ${if (e.seconds > 0) "${e.seconds} ثانیه" else "${e.sets} ست × ${e.reps} تکرار"}") }
        button("شروع و ثبت تمرین") { showWorkout() }
        button("انتخاب برنامه‌های محدودشونده") { showApps() }
        button("فعال‌سازی دسترسی محدودسازی") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        button("داشبورد پیشرفت") { showStats() }
        button("تنظیم زمان دسترسی") { chooseUnlockTime() }
        button("تنظیمات و بازیابی دسترسی") { prefs.edit().putLong("unlock_until", System.currentTimeMillis()+60*60*1000L).apply(); Toast.makeText(this,"دسترسی یک ساعت آزاد شد",Toast.LENGTH_LONG).show() }
    }
    private fun showWorkout() {
        base("ثبت تمرین امروز")
        label("هر حرکت را پس از انجام واقعی علامت بزن. این نسخه تأیید دستی است و ادعای تشخیص دوربین ندارد.")
        val checks = mutableListOf<Pair<CheckBox, Exercise>>()
        exercises.forEach { e -> val c=CheckBox(this).apply { text="${e.name} (${if(e.seconds>0) "${e.seconds} ثانیه" else "${e.sets} ست × ${e.reps}"})"; setTextColor(Color.WHITE) }; root.addView(c); checks.add(c to e) }
        button("ثبت پایان تمرین و ساخت استوری") {
            val done = checks.filter { it.first.isChecked }.map { it.second }
            if (done.isEmpty()) { Toast.makeText(this,"حداقل یک حرکت انجام‌شده را انتخاب کن.",Toast.LENGTH_SHORT).show(); return@button }
            val all = (prefs.getStringSet("done_dates", emptySet()) ?: emptySet()).toMutableSet(); val day=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date()); all.add(day)
            prefs.edit().putStringSet("done_dates",all).putInt("sessions",prefs.getInt("sessions",0)+1).putInt("reps",prefs.getInt("reps",0)+done.sumOf{it.reps*it.sets}).putInt("minutes",prefs.getInt("minutes",0)+done.sumOf{if(it.seconds>0) it.seconds else it.sets*it.reps*3}/60).putLong("unlock_until",System.currentTimeMillis()+prefs.getInt("unlock_minutes",30)*60*1000L).apply()
            val names=done.joinToString("، "){it.name}; val muscles=done.flatMap{it.muscles}.toSet()
            val file=StoryMaker.create(this, names, done.sumOf{it.sets}, done.sumOf{it.reps*it.sets}, muscles, all.size)
            base("تمرین ثبت شد")
            label("حرکت‌های ثبت‌شده: $names")
            label("عضلات درگیر امروز: ${muscles.mapNotNull{WorkoutData.muscleNames[it]}.distinct().joinToString("، ").ifBlank { "تمرین کششی/ریکاوری" }}")
            button("ذخیره استوری در گالری") { saveGallery(file) }
            button("اشتراک‌گذاری تصویر") { share(file) }
            button("بازگشت خانه") { showHome() }
        }
        button("برگشت") { showHome() }
    }
    private fun showApps() {
        base("انتخاب برنامه‌ها")
        label("این فهرست برنامه‌های قابل‌مشاهده روی گوشی را نشان می‌دهد. برنامه‌های حیاتی و تماس اضطراری را انتخاب نکن.")
        val pm=packageManager
        val intent=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps=pm.queryIntentActivities(intent,0).map { it.activityInfo.packageName to (it.loadLabel(pm).toString()) }.distinctBy{it.first}.sortedBy{it.second.lowercase()}
        apps.forEach { (pkg,name) ->
            if(pkg==packageName || pkg.startsWith("com.android.phone") || pkg.contains("emergency")) return@forEach
            val c=CheckBox(this).apply { text=name; tag=pkg; isChecked=selected.contains(pkg); setTextColor(Color.WHITE) }; root.addView(c)
        }
        button("ذخیره انتخاب‌ها") {
            selected.clear(); for(i in 0 until root.childCount) { val v=root.getChildAt(i); if(v is CheckBox && v.isChecked) selected.add(v.tag as String) }
            prefs.edit().putStringSet("selected_apps",selected).apply(); Toast.makeText(this,"${selected.size} برنامه انتخاب شد",Toast.LENGTH_SHORT).show(); showHome()
        }
        button("برگشت") { showHome() }
    }
    private fun chooseUnlockTime() {
        val options=arrayOf("۳۰ دقیقه","۴۵ دقیقه","۶۰ دقیقه")
        AlertDialog.Builder(this).setTitle("مدت دسترسی بعد از تمرین").setItems(options){_,which-> val m=listOf(30,45,60)[which]; prefs.edit().putInt("unlock_minutes",m).apply(); Toast.makeText(this,"زمان دسترسی: $m دقیقه",Toast.LENGTH_SHORT).show() }.show()
    }
    private fun showStats() { base("داشبورد پیشرفت"); label("جلسه‌های ثبت‌شده: ${prefs.getInt("sessions",0)}"); label("تکرارهای ثبت‌شده: ${prefs.getInt("reps",0)}"); label("دقیقه‌های تخمینی ورزش: ${prefs.getInt("minutes",0)}"); label("روزهای دارای ثبت تمرین: ${(prefs.getStringSet("done_dates",emptySet())?:emptySet()).size}"); label("سطح انگیزشی: ${when(prefs.getInt("sessions",0)){in 0..2->"مبتدی";in 3..9->"منظم";in 10..24->"ورزشکار";else->"قهرمان"}} (صرفاً انگیزشی)"); button("برگشت") { showHome() } }
    private fun saveGallery(file: File) {
        try { if(Build.VERSION.SDK_INT>=29){ val values=android.content.ContentValues().apply{put(android.provider.MediaStore.Images.Media.DISPLAY_NAME,file.name);put(android.provider.MediaStore.Images.Media.MIME_TYPE,"image/png");put(android.provider.MediaStore.Images.Media.RELATIVE_PATH,"Pictures/ProjectAmirali")}; val uri=contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)!!; contentResolver.openOutputStream(uri)!!.use{file.inputStream().copyTo(it)} } else { file.copyTo(File(getExternalFilesDir(null),file.name),true) }; Toast.makeText(this,"تصویر در گالری ذخیره شد",Toast.LENGTH_LONG).show() } catch(e:Exception){Toast.makeText(this,"ذخیره ناموفق: ${e.message}",Toast.LENGTH_LONG).show()}
    }
    private fun share(file: File) {
        try {
            val values=android.content.ContentValues().apply { put(android.provider.MediaStore.Images.Media.DISPLAY_NAME,file.name); put(android.provider.MediaStore.Images.Media.MIME_TYPE,"image/png"); put(android.provider.MediaStore.Images.Media.RELATIVE_PATH,"Pictures/ProjectAmirali") }
            val uri=contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)!!
            contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().copyTo(out) }
            val i=Intent(Intent.ACTION_SEND).apply { type="image/png"; putExtra(Intent.EXTRA_STREAM,uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            startActivity(Intent.createChooser(i,"اشتراک‌گذاری استوری"))
        } catch(e:Exception) { Toast.makeText(this,"اشتراک‌گذاری ناموفق: ${e.message}",Toast.LENGTH_LONG).show() }
    }
}

object StoryMaker {
    fun create(ctx: Context, names:String, sets:Int, reps:Int, muscles:Set<String>, day:Int): File {
        val bmp=Bitmap.createBitmap(1080,1920,Bitmap.Config.ARGB_8888); val c=Canvas(bmp); c.drawColor(Color.rgb(15,17,23))
        val p=Paint(3); p.color=Color.rgb(255,122,24); p.textSize=64f; p.typeface=Typeface.create("sans-serif",Typeface.BOLD); c.drawText("پروژه امیرعلی",650f,130f,p)
        p.color=Color.WHITE;p.textSize=36f;c.drawText("گزارش تمرین | روز $day",600f,195f,p)
        p.color=Color.rgb(35,38,47); c.drawRoundRect(70f,260f,1010f,1250f,32f,32f,p)
        drawPerson(c,330f,360f,muscles,false); drawPerson(c,720f,360f,muscles,true)
        p.color=Color.WHITE;p.textSize=29f;p.typeface=Typeface.create("sans-serif",Typeface.NORMAL); c.drawText("نمای جلو",260f,850f,p); c.drawText("نمای پشت",650f,850f,p)
        p.color=Color.rgb(255,122,24);p.textSize=39f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText("تمرین‌های انجام‌شده",690f,1340f,p)
        p.color=Color.WHITE;p.textSize=30f
        wrap(c,names,950f,1400f,50f,p)
        c.drawText("ست‌های ثبت‌شده: $sets",650f,1580f,p); c.drawText("تکرارهای ثبت‌شده: $reps",650f,1640f,p)
        p.color=Color.rgb(255,122,24);p.textSize=38f;c.drawText("هر روز یک قدم قوی‌تر.",610f,1790f,p)
        p.color=Color.LTGRAY;p.textSize=22f;c.drawText("نقشه آموزشی عضلات درگیر تمرین",560f,1850f,p)
        val file=File(ctx.cacheDir,"amirali_story_${System.currentTimeMillis()}.png"); FileOutputStream(file).use{bmp.compress(Bitmap.CompressFormat.PNG,100,it)}; bmp.recycle(); return file
    }
    private fun drawPerson(c:Canvas,cx:Float,top:Float,m:Set<String>,back:Boolean) {
        val p=Paint(3);p.color=Color.rgb(190,193,199)
        c.drawCircle(cx,top+45f,36f,p); c.drawRoundRect(cx-36f,top+85f,cx+36f,top+300f,25f,25f,p)
        c.drawRoundRect(cx-100f,top+95f,cx-38f,top+275f,25f,25f,p);c.drawRoundRect(cx+38f,top+95f,cx+100f,top+275f,25f,25f,p)
        c.drawRoundRect(cx-32f,top+295f,cx-3f,top+500f,12f,12f,p);c.drawRoundRect(cx+3f,top+295f,cx+32f,top+500f,12f,12f,p)
        val red=Paint(3).apply{color=Color.rgb(238,67,45)};val yellow=Paint(3).apply{color=Color.rgb(255,194,55)}
        fun muscle(key:String,x1:Float,y1:Float,x2:Float,y2:Float,main:Boolean=true){ if(m.contains(key)) c.drawRoundRect(cx+x1,top+y1,cx+x2,top+y2,12f,12f,if(main)red else yellow) }
        if(!back){muscle("chest",-32f,120f,32f,185f);muscle("frontShoulder",-70f,100f,-35f,150f,false);muscle("frontShoulder",35f,100f,70f,150f,false);muscle("triceps",-92f,165f,-45f,235f,false);muscle("triceps",45f,165f,92f,235f,false);muscle("quads",-30f,310f,-5f,390f);muscle("quads",5f,310f,30f,390f);muscle("glutes",-32f,265f,32f,315f);muscle("core",-23f,190f,23f,270f,false)}
        else {muscle("lats",-34f,135f,34f,230f);muscle("upperBack",-33f,100f,33f,160f,false);muscle("biceps",-95f,160f,-50f,225f,false);muscle("biceps",50f,160f,95f,225f,false);muscle("hamstrings",-30f,330f,-5f,405f);muscle("hamstrings",5f,330f,30f,405f);muscle("glutes",-32f,265f,32f,315f)}
    }
    private fun wrap(c:Canvas,text:String,maxWidth:Float,startY:Float,lineH:Float,p:Paint){ var y=startY; var line=""; text.split(" ").forEach{w-> val n=if(line.isEmpty())w else "$line $w"; if(p.measureText(n)>maxWidth){c.drawText(line,70f,y,p);y+=lineH;line=w}else line=n}; if(line.isNotEmpty())c.drawText(line,70f,y,p) }
}
