package com.amirali.project

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class AppGuardService : AccessibilityService() {
    private var lastBlocked = ""
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.amirali.project") { lastBlocked = ""; return }
        val prefs = getSharedPreferences("amirali", MODE_PRIVATE)
        val selected = prefs.getStringSet("selected_apps", emptySet()) ?: emptySet()
        val until = prefs.getLong("unlock_until", 0L)
        if (pkg in selected && System.currentTimeMillis() >= until && pkg != lastBlocked) {
            lastBlocked = pkg
            startActivity(Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("blocked_package", pkg))
        }
        if (pkg !in selected) lastBlocked = ""
    }
    override fun onInterrupt() {}
}
