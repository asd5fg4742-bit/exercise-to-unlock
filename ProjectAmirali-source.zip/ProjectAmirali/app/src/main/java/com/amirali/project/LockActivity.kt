package com.amirali.project

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class LockActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(28,28,28,28); setBackgroundColor(Color.rgb(16,17,22)) }
        layout.addView(TextView(this).apply { text="اول تمرین، بعد سرگرمی"; textSize=26f; setTextColor(Color.rgb(255,122,24)); gravity=Gravity.CENTER })
        layout.addView(TextView(this).apply { text="این برنامه تا ثبت تمرین محدود است. اگر اشتباهی قفل شدی، از گزینه بازیابی دسترسی در برنامه پروژه امیرعلی استفاده کن."; textSize=18f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; setPadding(0,28,0,28) })
        layout.addView(Button(this).apply { text="رفتن به پروژه امیرعلی"; setOnClickListener { startActivity(Intent(this@LockActivity, MainActivity::class.java)); finish() } })
        layout.addView(Button(this).apply { text="تنظیمات دسترسی‌پذیری"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        setContentView(layout, ViewGroup.LayoutParams(-1,-1))
    }
}
