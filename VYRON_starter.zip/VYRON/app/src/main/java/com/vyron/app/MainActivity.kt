package com.vyron.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection

private val Bg = Color(0xFF080B0A)
private val Panel = Color(0xFF141A17)
private val Neon = Color(0xFFB6FF39)
private val MainText = Color(0xFFF2F5F2)
private val Muted = Color(0xFF9BA69E)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { VyronApp() } }
    }
}

data class Feature(val title: String, val subtitle: String, val icon: ImageVector)

@Composable
fun VyronApp() {
    var selected by remember { mutableStateOf("خانه") }
    val features = listOf(
        Feature("برنامه‌ریزی", "درس، تکلیف و امتحان", Icons.Default.CalendarMonth),
        Feature("تمرین ورزشی", "فوتبال و تمرین قدرتی", Icons.Default.FitnessCenter),
        Feature("تمرکز", "جلسه تمرکز و زمان‌سنج", Icons.Default.Timer),
        Feature("کارها", "فهرست کارهای روزانه", Icons.Default.CheckCircle),
        Feature("پیشرفت", "ثبت فعالیت‌ها", Icons.Default.TrendingUp),
        Feature("پروفایل", "هدف‌ها و مشخصات", Icons.Default.Person)
    )
    MaterialTheme(colorScheme = darkColorScheme(primary = Neon, background = Bg, surface = Panel, onPrimary = Color.Black, onBackground = MainText, onSurface = MainText)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("خانه" to Icons.Default.Home, "برنامه" to Icons.Default.CalendarMonth, "تمرین" to Icons.Default.FitnessCenter, "پروفایل" to Icons.Default.Person).forEach { (label, icon) ->
                    NavigationBarItem(selected = selected == label, onClick = { selected = label }, icon = { Icon(icon, contentDescription = label) }, label = { Text(label) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Neon, selectedTextColor = Neon, indicatorColor = Color(0xFF26351B), unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().background(Bg).padding(padding).padding(horizontal = 18.dp, vertical = 14.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column { Text("VYRON", color = Neon, fontSize = 28.sp, fontWeight = FontWeight.Black); Text("کنترل روزت دست خودته", color = Muted, fontSize = 13.sp) }
                    Surface(shape = RoundedCornerShape(14.dp), color = Panel) { IconButton(onClick = { selected = "پروفایل" }) { Icon(Icons.Default.Settings, contentDescription = "تنظیمات", tint = Neon) } }
                }
                Spacer(Modifier.height(22.dp))
                Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), color = Color(0xFF1A2416)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("امروز رو بساز", color = MainText, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp)); Text("یک کار کوچک، شروع یک روز بهتره.", color = Muted, fontSize = 14.sp)
                        Spacer(Modifier.height(14.dp))
                        Button(onClick = { selected = "برنامه" }, colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Color.Black), shape = RoundedCornerShape(12.dp)) { Text("دیدن برنامه", fontWeight = FontWeight.Bold) }
                    }
                }
                Spacer(Modifier.height(22.dp)); Text("بخش‌های اصلی", color = MainText, fontSize = 18.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp))
                LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()) {
                    items(features) { feature -> FeatureCard(feature) { selected = feature.title } }
                }
            }
        }
    }
}

@Composable
fun FeatureCard(feature: Feature, onClick: () -> Unit) {
    Surface(onClick = onClick, color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.height(126.dp)) {
        Column(Modifier.fillMaxSize().padding(15.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(feature.icon, contentDescription = feature.title, tint = Neon, modifier = Modifier.size(27.dp))
            Column { Text(feature.title, color = MainText, fontWeight = FontWeight.Bold, fontSize = 15.sp); Spacer(Modifier.height(3.dp)); Text(feature.subtitle, color = Muted, fontSize = 11.sp) }
        }
    }
}
